#!usr/bin/perl

use lib;
use menu;

sub main{
	
	menu::header();
	menu::option();
	menu::process();
	
	}
	
END{
	print "Program Ended";
}
		
main();








